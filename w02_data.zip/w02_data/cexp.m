function f = cexp(a,b)
    f = exp(a+b*2);
end